define(['knockout', 'jquery','appController', "ojs/ojbootstrap", "gridDataProvider/DemoArrayDataGridProvider",
        "gridDataProvider/population.json", "ojs/ojconverter-datetime", "ojs/ojconverter-number", 
        "ojs/ojdatagrid", "ojs/ojknockout", "ojs/ojformlayout", "ojs/ojinputtext", "ojs/ojdatetimepicker", "ojs/ojselectcombobox", "ojs/ojlabelvalue"],
        function (ko, $,app,ojbootstrap_1, DemoArrayDataGridProvider_1, jsonData, ojconverter_datetime_1, ojconverter_number_1) {

            class InitialLoadViewModel {
 
                constructor(args) {
                var self = this;
                self.DepName = args.routerState.detail.dep_url;

                this.jsonData = JSON.parse(jsonData);
                this.rowHeaders = [
                    this.jsonData.map((item) => {
                        return item.index;
                    })
                ];
                this.columnHeaders = [
                    Object.keys(this.jsonData[0]).filter((key) => {
                        return key !== 'index';
                    })
                ];
                this.data = this.jsonData.map((item) => {
                    return this.columnHeaders[0].map((header) => {
                        return { data: item[header] };
                    });
                });
                this.dataGridProvider = new DemoArrayDataGridProvider_1.DemoArrayDataGridProvider({
                    data: this.data,
                    rowHeader: this.rowHeaders,
                    columnHeader: this.columnHeaders
                }, {}, {});
                this.dateConverter = new ojconverter_datetime_1.IntlDateTimeConverter({
                    formatType: 'date',
                    dateFormat: 'medium'
                });
                this.numberConverter = new ojconverter_number_1.IntlNumberConverter({
                    style: 'currency',
                    currency: 'USD',
                    currencyDisplay: 'symbol'
                });
                this.formatColumnHeader = (headerContext) => {
                    const data = headerContext.item.data;
                    return data.replace(/([A-Z])/g, ' $1').replace(/^./, function (str) {
                        return str.toUpperCase();
                    });
                };
                this.getColumnHeaderStyle = (headerContext) => {
                    const columnIndex = headerContext.index;
                    if (columnIndex === 8) {
                        return 'width:175px';
                    }
                    else if (columnIndex === 3 || columnIndex === 5 || columnIndex === 16) {
                        return 'width:150px';
                    }
                    else if (columnIndex === 4) {
                        return 'width:185px;';
                    }
                    else if (columnIndex === 9 || columnIndex === 11 || columnIndex === 13) {
                        return 'width:250px;';
                    }
                    return 'width:125px;';
                };
                this.getColumnHeaderClassName = (headerContext) => {
                    return this.getAlignmentClassNameByIndex(headerContext.index);
                };
                this.getCellClassName = (cellContext) => {
                    return this.getAlignmentClassNameByIndex(cellContext.indexes.column);
                };
                this.getAlignmentClassNameByIndex = (index) => {
                    if (this.numericIndexes.includes(index) || index === 15) {
                        return 'oj-helper-justify-content-right oj-helper-text-align-right';
                    }
                    return 'oj-sm-justify-content-flex-start oj-sm-text-align-start';
                };
                this.editedData = ko.observable('None Edited Yet');
                this.oldData = ko.observable('None Edited Yet');
                this.editedIndexes = ko.observable('None Edited Yet');
                this.editMode = 'cellEdit';
                this.handleEdit = (event) => {
                    // store the original data in case of a cancel
                    // now data is going to be directly modified by the input control
                    this.originalData = Object.assign({}, event.detail.cellContext.data);
                };
                // handle validation of editable components and when edit has been cancelled
                this.handleEditEnd = (event) => {
                    this.editedData('');
                    const detail = event.detail;
                    if (detail.cancelEdit) {
                        // write back to the data object, in this instance of the DemoArrayDataGridProvider
                        // the data is returned as {data: } so we get it from data, others
                        // may have more complex reverting of data
                        event.detail.cellContext.data.data = this.originalData.data;
                        return;
                    }
                    const rowIndex = event.detail.cellContext.indexes.row;
                    const columnIndex = event.detail.cellContext.indexes.column;
                    // run validation on the editable element inside of the table
                    // this assume one editable component per cell
                    const editable = event.target.querySelector('.editable');
                    editable.validate();
                    // DataGrid does not currently support editables with async validators
                    // so treating editable with 'pending' state as invalid and do not allow
                    // editing to end
                    if (editable.valid !== 'valid') {
                        event.preventDefault();
                    }
                    else {
                        // there is a valid edited value on event.detail.cellContext.data
                        // that in our case should look like {data: newValue}
                        // this is the place to either buffer these cells for submission to a backend later
                        // or write them back immediately as is being done here considering the
                        // index based nature of the edit
                        this.data[rowIndex][columnIndex] = event.detail.cellContext.data.data;
                        this.editedData(event.detail.cellContext.data.data);
                        this.oldData(this.originalData.data);
                        this.editedIndexes(rowIndex + ',' + columnIndex);
                    }
                };
                let firstRowValues = Object.values(this.data[0]);
                this.numericIndexes = firstRowValues.reduce((numeric, data, index) => {
                    if (!isNaN(data.data) || !isNaN(Date.parse(data.data))) {
                        numeric.push(index);
                    }
                    return numeric;
                }, []);


                  self.connected = function () { 
                    if (sessionStorage.getItem("userName")==null) {
                        self.router.go({path : 'signin'});
                    }
                    else
                    {
                    app.onAppSuccess();
                    }
                    }
                

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {

                    // Implement if needed
                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {

                };
        }
    }
            return  InitialLoadViewModel;
        }
);