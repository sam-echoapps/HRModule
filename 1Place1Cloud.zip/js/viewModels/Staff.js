/**
 * @license
 * Copyright (c) 2014, 2023, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
/*
 * Your dashboard ViewModel code goes here
 */i
define(['../accUtils', "ojs/ojinputtext", "ojs/ojselectsingle", "ojs/ojformlayout", "ojs/ojbutton", "ojs/ojhybridp"],
 function(accUtils) {
    function DashboardViewModel() {
      
      this.connected = () => {
      };
    }
    return DashboardViewModel;
  }
);